README - Assignment 2 - Pierre-Yves Sojic

Build Instructions:
-------------------
1. To build the program:
   make

2. To run the program:
   sinteractive --time=0:30:0 --cpus-per-task=8 --account=finm32950
   ./option_pricer


