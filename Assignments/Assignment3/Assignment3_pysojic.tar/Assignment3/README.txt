README - Assignment 3 - Pierre-Yves Sojic

Build Instructions:
-------------------
1. To build the program:
   make

2. To run the program:
   sinteractive --partition=gpu --gres=gpu:1 --time=0:30:00 --account=finm32950
   ./bs_simple



